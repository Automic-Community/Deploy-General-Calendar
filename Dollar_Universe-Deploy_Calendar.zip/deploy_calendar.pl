### =============================================================================== ###
### Deploy the general calendar to a selection of nodes
### =============================================================================== ###

### =============================================================================== ###
### Arguments and varaible

# Check DU variables
if (length($ENV{'U_TMP_PATH'})==0) {
    print("Error: Dollar Universe environment is not loaded. Please load uxsetenv\n");
    print("  Please load uxsetenv.\n");
    exit 1;
}

# Temp file
my $TMP_EXTRACT_CAL=$ENV{'U_TMP_PATH'}."TMP_DEPL_DUAS_CAL.ext";

# Node filter
my $nb_arg=scalar @ARGV;
if ($nb_arg<1) {
    error_arguments();
}
my $NODE_FILTER_ARG = $ARGV[0];
my @TMP_ARG = split('NODE=', $NODE_FILTER_ARG);
$NODE_FILTER=@TMP_ARG[1];
if (length($NODE_FILTER)==0) {
    my @TMP_ARG = split('node=', $NODE_FILTER_ARG);
    $NODE_FILTER=@TMP_ARG[1];
    if (length($NODE_FILTER)==0) {
        error_arguments();
    }
}


### =============================================================================== ###
### Main procedure ###

print("\n");
print("------------------------------------------------\n");
print("------------------------------------------------\n");
print("Deploy the calendar on selected nodes\n");
print("------------------------------------------------\n");
print("------------------------------------------------\n");
print("\n");

# Export the calendar in a temporary file
print("------------------------------------------------\n");
print("Extract Current General Calendar\n");
system("cd ".$ENV{'UXEXE'}." && uxext CAL output=".$TMP_EXTRACT_CAL." REPL UG=\" \"");
print("\n");

# Get the list of nodes
my $NODE_LIST = `$ENV{'UXEXE'}/uxshw node tnode=$NODE_FILTER`;
my @NODE_LIST_SPLIT = split('\n', $NODE_LIST);
my $NODE_NAME="";

foreach my $LINE (@NODE_LIST_SPLIT) {
    # Is is the node name?
    if (index($LINE,"ITEMS | tnode")>-1) {
        
        # Extracting node name
        print("------------------------------------------------\n");
        my @TMP = split(':', $LINE);
        $NODE_NAME=@TMP[1];
        $NODE_NAME =~ s/ //g;
        print("Checking Node: ".$NODE_NAME."\n");

        # if node reachable
        if (du_check_io($NODE_NAME)>-1) {
            system("cd ".$ENV{'UXEXE'}." && uxins CAL input=".$TMP_EXTRACT_CAL." CIBLE=\" \" REPL node=".$NODE_NAME);
        }
    }
}

# Cleanup and exit
# unlink($TMP_EXTRACT_CAL);

exit 0;


### =============================================================================== ###
### Functions ###

## Exit in error because not the right script arguments
sub error_arguments {
    print("Error: incorrect parameters\n");
    print("  Expected parameter: NODE=<NODE_FILTER>\n");
    print("  (value can be a node or a node pattern with *)\n");
    exit 1;
}

## Check if the node is reachable
# Parameter: 1. NodeName
sub du_check_io {
    my $NODE = $_[0];
    my $NODE_STATUS = `$ENV{'UXEXE'}/uxlst ATM node=$NODE`;
    if (index($NODE_STATUS,"Launcher")>0) {
        print("Node reachable\n");
        return 1;
    } else {
        print("ERROR: Node unreachable\n");
        return -1;
    }
}

